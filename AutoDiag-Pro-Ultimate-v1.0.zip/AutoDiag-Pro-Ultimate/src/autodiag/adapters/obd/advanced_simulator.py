"""Erweiterter Simulator mit realistischen Live-Daten und Fehlersimulation."""
import random
from datetime import datetime
from typing import List, Optional, Dict, Any
import logging
from .base import BaseOBDAdapter
from ...core.models import LiveData, FreezeFrame

logger = logging.getLogger(__name__)

class AdvancedSimulator(BaseOBDAdapter):
    """Professioneller Simulator für Demo, Schulungen und Tests."""

    VEHICLES = {
        "BMW_E90": {"make": "BMW", "model": "E90 320i", "year": 2010, "engine": "2.0L N43"},
        "VW_GOLF7": {"make": "VW", "model": "Golf VII 1.4 TSI", "year": 2015, "engine": "1.4L EA211"},
        "MERCEDES_W204": {"make": "Mercedes", "model": "C 200 CGI", "year": 2012, "engine": "2.0L M271"},
    }

    SCENARIOS = {
        "keine_fehlers": {"dtcs": [], "rpm_range": (700, 800), "coolant_temp": (85, 95), "speed_range": (0, 5)},
        "katalysator": {"dtcs": ["P0420"], "rpm_range": (700, 850), "coolant_temp": (85, 95), "speed_range": (0, 10)},
        "mageres_gemisch": {"dtcs": ["P0171"], "rpm_range": (650, 900), "coolant_temp": (80, 90), "speed_range": (0, 10)},
        "fehlzuendung": {"dtcs": ["P0300", "P0301"], "rpm_range": (500, 1000), "coolant_temp": (75, 90), "speed_range": (0, 5)},
        "motorprobleme": {"dtcs": ["P0300", "P0171", "P0420"], "rpm_range": (500, 900), "coolant_temp": (75, 95), "speed_range": (0, 10)},
    }

    def __init__(self, scenario: str = "keine_fehlers", vehicle: str = "BMW_E90"):
        super().__init__(timeout=5.0)
        self.scenario = scenario
        self.vehicle = vehicle
        self._connected = False
        self._last_live_data = LiveData()

    def _connect_impl(self) -> bool:
        self._connected = True
        logger.info(f"Simulator gestartet: {self.vehicle} – Szenario: {self.scenario}")
        return True

    def _disconnect_impl(self) -> None:
        self._connected = False
        logger.info("Simulator gestoppt")

    def _get_dtcs_impl(self) -> Optional[List[str]]:
        if not self._connected:
            return None
        scenario = self.SCENARIOS.get(self.scenario, self.SCENARIOS["keine_fehlers"])
        return scenario["dtcs"].copy()

    def _clear_dtcs_impl(self) -> bool:
        return True

    def _get_live_data_impl(self) -> Optional[LiveData]:
        if not self._connected:
            return None
        scenario = self.SCENARIOS.get(self.scenario, self.SCENARIOS["keine_fehlers"])
        data = LiveData()
        data.rpm = scenario["rpm_range"][0] + (scenario["rpm_range"][1] - scenario["rpm_range"][0]) * (0.5 + 0.5 * random.random())
        data.speed = scenario["speed_range"][0] + (scenario["speed_range"][1] - scenario["speed_range"][0]) * random.random()
        data.coolant_temp = scenario["coolant_temp"][0] + (scenario["coolant_temp"][1] - scenario["coolant_temp"][0]) * random.random()
        data.engine_load = 10 + 20 * random.random()
        data.throttle_position = 5 + 15 * random.random()
        data.maf = 2 + 5 * random.random()
        data.map = 30 + 40 * random.random()
        data.lambda_value = 0.98 + 0.04 * random.random()
        data.battery_voltage = 12.5 + 1.0 * random.random()
        data.fuel_level = 30 + 60 * random.random()
        data.intake_temp = 20 + 30 * random.random()
        data.timing_advance = 5 + 15 * random.random()
        self._last_live_data = data
        return data

    def _get_freeze_frame_impl(self, dtc: str) -> Optional[FreezeFrame]:
        live_data = self._get_live_data_impl()
        if live_data:
            return FreezeFrame(timestamp=datetime.now(), dtc_code=dtc, live_data=live_data, environment={"simulated": "true"})
        return None

    def get_vehicle_info(self) -> Dict[str, str]:
        vehicle = self.VEHICLES.get(self.vehicle, self.VEHICLES["BMW_E90"])
        return {
            "VIN": f"SIM-{random.randint(100000, 999999)}",
            "Make": vehicle["make"],
            "Model": vehicle["model"],
            "Year": str(vehicle["year"]),
            "Engine": vehicle["engine"],
            "Adapter": "Advanced Simulator",
            "Scenario": self.scenario
        }

    def set_scenario(self, scenario: str) -> None:
        if scenario in self.SCENARIOS:
            self.scenario = scenario
            logger.info(f"Szenario gewechselt: {scenario}")

    def get_scenarios(self) -> List[str]:
        return list(self.SCENARIOS.keys())

    def get_vehicles(self) -> List[str]:
        return list(self.VEHICLES.keys())