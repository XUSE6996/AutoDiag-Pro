"""ELM327-Adapter mit python-obd – erweitert für Live-Daten und Freeze Frame."""
try:
    import obd
except ImportError:
    obd = None
from typing import List, Optional, Dict, Any
import logging
from .base import BaseOBDAdapter
from ...core.models import LiveData, FreezeFrame

logger = logging.getLogger(__name__)

class ELM327Adapter(BaseOBDAdapter):
    """ELM327-Adapter (USB/Bluetooth) mit vollständiger OBD-II-Unterstützung."""

    def __init__(self, port: Optional[str] = None, timeout: float = 5.0):
        super().__init__(timeout=timeout)
        self.port = port
        self._connection = None

    def _connect_impl(self) -> bool:
        if obd is None:
            logger.error("python-obd nicht installiert")
            return False
        try:
            self._connection = obd.OBD(portstr=self.port, timeout=self.timeout, fast=False)
            return self._connection.is_connected()
        except Exception as e:
            logger.exception(f"ELM327-Verbindungsfehler: {e}")
            return False

    def _disconnect_impl(self) -> None:
        if self._connection:
            self._connection.close()
            self._connection = None

    def _get_dtcs_impl(self) -> Optional[List[str]]:
        if not self._connection:
            return None
        try:
            response = self._connection.query(obd.commands.GET_DTCS)
            if response and response.value:
                return response.value.magnitude
            return []
        except Exception as e:
            logger.exception(f"DTC-Lese-Fehler: {e}")
            return None

    def _clear_dtcs_impl(self) -> bool:
        if not self._connection:
            return False
        try:
            response = self._connection.query(obd.commands.CLEAR_DTCS)
            return response and response.value
        except Exception as e:
            logger.exception(f"DTC-Lösch-Fehler: {e}")
            return False

    def _get_live_data_impl(self) -> Optional[LiveData]:
        if not self._connection:
            return None
        data = LiveData()
        commands = [
            (obd.commands.RPM, "rpm"),
            (obd.commands.SPEED, "speed"),
            (obd.commands.COOLANT_TEMP, "coolant_temp"),
            (obd.commands.ENGINE_LOAD, "engine_load"),
            (obd.commands.THROTTLE_POS, "throttle_position"),
            (obd.commands.MAF, "maf"),
            (obd.commands.MAP, "map"),
            (obd.commands.O2_B1S1, "lambda_value"),
            (obd.commands.BATTERY_VOLTAGE, "battery_voltage"),
            (obd.commands.FUEL_LEVEL, "fuel_level"),
            (obd.commands.INTAKE_TEMP, "intake_temp"),
            (obd.commands.TIMING_ADVANCE, "timing_advance"),
        ]
        for cmd, attr in commands:
            response = self._connection.query(cmd)
            if response and response.value:
                value = float(response.value.magnitude)
                if attr == "engine_load" or attr == "throttle_position" or attr == "fuel_level":
                    value *= 100
                setattr(data, attr, value)
        return data

    def _get_freeze_frame_impl(self, dtc: str) -> Optional[FreezeFrame]:
        live_data = self._get_live_data_impl()
        if live_data:
            return FreezeFrame(
                timestamp=live_data.timestamp,
                dtc_code=dtc,
                live_data=live_data,
                environment={}
            )
        return None

    def get_vehicle_info(self) -> Dict[str, str]:
        info = {}
        if not self._connection:
            return info
        try:
            response = self._connection.query(obd.commands.VIN)
            if response and response.value:
                info["VIN"] = str(response.value)
        except:
            pass
        return info