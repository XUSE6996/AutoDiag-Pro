"""CANable-Adapter – professionelle CAN-Bus-Anbindung (USB-CAN)."""
from typing import List, Optional, Dict, Any
import logging
from .base import BaseOBDAdapter
from ...core.models import LiveData, FreezeFrame
from ...core.exceptions import OBDConnectionError

logger = logging.getLogger(__name__)

class CANableAdapter(BaseOBDAdapter):
    """CANable-Adapter für professionelle CAN-Bus-Diagnose."""

    def __init__(self, port: str = "auto", baudrate: int = 500000, timeout: float = 5.0):
        super().__init__(timeout=timeout)
        self.port = port
        self.baudrate = baudrate
        self._interface = None
        self._can_available = False

    def _connect_impl(self) -> bool:
        try:
            import can
            from can.interfaces.serial import SerialBus
            import serial.tools.list_ports

            if self.port == "auto":
                for port in serial.tools.list_ports.comports():
                    if "CANable" in port.description or "USB" in port.description:
                        self.port = port.device
                        break
                else:
                    logger.error("Kein CANable-Adapter gefunden")
                    return False

            self._interface = SerialBus(channel=self.port, baudrate=self.baudrate, timeout=self.timeout)
            self._can_available = True
            return True
        except ImportError:
            logger.error("python-can nicht installiert. Bitte: pip install python-can")
            return False
        except Exception as e:
            logger.exception(f"CANable-Verbindungsfehler: {e}")
            return False

    def _disconnect_impl(self) -> None:
        if self._interface:
            self._interface.shutdown()
            self._interface = None
        self._can_available = False

    def _get_dtcs_impl(self) -> Optional[List[str]]:
        logger.warning("CANable: DTC-Lesen nur über UDS möglich.")
        return []

    def _clear_dtcs_impl(self) -> bool:
        logger.warning("CANable: DTC-Löschen nur über UDS möglich.")
        return False

    def _get_live_data_impl(self) -> Optional[LiveData]:
        return LiveData()

    def _get_freeze_frame_impl(self, dtc: str) -> Optional[FreezeFrame]:
        return None

    def get_vehicle_info(self) -> Dict[str, str]:
        return {"Adapter": "CANable"}

    def send_can_message(self, arbitration_id: int, data: bytes) -> bool:
        if not self._interface:
            raise OBDConnectionError("CANable nicht verbunden")
        try:
            import can
            msg = can.Message(arbitration_id=arbitration_id, data=data, is_extended_id=False)
            self._interface.send(msg)
            return True
        except Exception as e:
            logger.exception(f"CAN-Senden fehlgeschlagen: {e}")
            return False

    def receive_can_messages(self, timeout: float = 1.0) -> List[Dict]:
        if not self._interface:
            return []
        messages = []
        try:
            import can
            while True:
                msg = self._interface.recv(timeout=timeout)
                if not msg:
                    break
                messages.append({
                    "timestamp": msg.timestamp,
                    "arbitration_id": msg.arbitration_id,
                    "data": msg.data.hex(),
                    "dlc": msg.dlc
                })
        except Exception as e:
            logger.exception(f"CAN-Empfang fehlgeschlagen: {e}")
        return messages