"""Basis-Adapter mit gemeinsamer Logik für alle OBD-Adapter."""
from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any
import logging
from ...core.interfaces import IOBDAdapter
from ...core.models import LiveData, FreezeFrame
from ...core.exceptions import OBDConnectionError

logger = logging.getLogger(__name__)

class BaseOBDAdapter(IOBDAdapter, ABC):
    """Basis-Adapter mit gemeinsamer Live-Daten-Logik."""

    def __init__(self, timeout: float = 5.0):
        self.timeout = timeout
        self._connected = False
        self._last_live_data: Optional[LiveData] = None

    @abstractmethod
    def _connect_impl(self) -> bool:
        pass

    @abstractmethod
    def _disconnect_impl(self) -> None:
        pass

    @abstractmethod
    def _get_dtcs_impl(self) -> Optional[List[str]]:
        pass

    @abstractmethod
    def _clear_dtcs_impl(self) -> bool:
        pass

    @abstractmethod
    def _get_live_data_impl(self) -> Optional[LiveData]:
        pass

    @abstractmethod
    def _get_freeze_frame_impl(self, dtc: str) -> Optional[FreezeFrame]:
        pass

    def connect(self) -> bool:
        logger.info(f"{self.__class__.__name__}: Verbinde...")
        try:
            result = self._connect_impl()
            self._connected = result
            if result:
                logger.info(f"{self.__class__.__name__}: Verbunden")
            else:
                logger.warning(f"{self.__class__.__name__}: Verbindung fehlgeschlagen")
            return result
        except Exception as e:
            logger.exception(f"{self.__class__.__name__}: Verbindungsfehler: {e}")
            return False

    def disconnect(self) -> None:
        logger.info(f"{self.__class__.__name__}: Trenne...")
        try:
            self._disconnect_impl()
            self._connected = False
            logger.info(f"{self.__class__.__name__}: Getrennt")
        except Exception as e:
            logger.exception(f"{self.__class__.__name__}: Trennen fehlgeschlagen: {e}")

    def get_dtcs(self) -> Optional[List[str]]:
        if not self._connected:
            raise OBDConnectionError("Adapter nicht verbunden")
        try:
            return self._get_dtcs_impl()
        except Exception as e:
            logger.exception(f"Fehler beim DTC-Lesen: {e}")
            return None

    def clear_dtcs(self) -> bool:
        if not self._connected:
            raise OBDConnectionError("Adapter nicht verbunden")
        try:
            result = self._clear_dtcs_impl()
            logger.info(f"DTCs gelöscht: {result}")
            return result
        except Exception as e:
            logger.exception(f"Fehler beim DTC-Löschen: {e}")
            return False

    def get_live_data(self) -> Optional[LiveData]:
        if not self._connected:
            raise OBDConnectionError("Adapter nicht verbunden")
        try:
            data = self._get_live_data_impl()
            if data:
                self._last_live_data = data
            return data
        except Exception as e:
            logger.exception(f"Fehler beim Live-Daten-Lesen: {e}")
            return self._last_live_data

    def get_freeze_frame(self, dtc: str) -> Optional[FreezeFrame]:
        if not self._connected:
            raise OBDConnectionError("Adapter nicht verbunden")
        try:
            return self._get_freeze_frame_impl(dtc)
        except Exception as e:
            logger.exception(f"Fehler beim Freeze-Frame-Lesen: {e}")
            return None

    def get_vehicle_info(self) -> Dict[str, str]:
        return {}

    def is_connected(self) -> bool:
        return self._connected