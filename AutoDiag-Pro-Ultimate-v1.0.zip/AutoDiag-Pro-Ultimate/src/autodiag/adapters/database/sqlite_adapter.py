"""Erweiterte SQLite-Datenbank mit Fahrzeugprofilen und Scan-Historie."""
import sqlite3
import json
from pathlib import Path
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging
from ...core.interfaces import IDTCDatabase
from ...core.models import DtcCode, VehicleProfile, ScanResult, DTCSeverity, DTCSystem
from ...core.exceptions import DatabaseError

logger = logging.getLogger(__name__)

class SQLiteDTCAdapter(IDTCDatabase):
    CURRENT_VERSION = "2026.1"

    def __init__(self, db_path: Path, seed_path: Optional[Path] = None):
        self.db_path = db_path
        self.seed_path = seed_path
        self._init_db()
        self._seed_if_empty()

    def _init_db(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS dtc_codes (code TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL, severity TEXT NOT NULL, system TEXT NOT NULL, possible_causes TEXT, recommended_actions TEXT, extra TEXT, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
            conn.execute("CREATE TABLE IF NOT EXISTS vehicle_profiles (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, make TEXT NOT NULL, model TEXT NOT NULL, year INTEGER, vin TEXT, engine TEXT, mileage INTEGER, license_plate TEXT, notes TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
            conn.execute("CREATE TABLE IF NOT EXISTS scan_history (id INTEGER PRIMARY KEY AUTOINCREMENT, vehicle_profile_id INTEGER, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, dtc_codes TEXT, raw_dtc_list TEXT, live_data TEXT, freeze_frame TEXT, vehicle_info TEXT, adapter_info TEXT, error TEXT, notes TEXT, FOREIGN KEY (vehicle_profile_id) REFERENCES vehicle_profiles(id))")
            conn.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            conn.execute("INSERT OR IGNORE INTO metadata (key, value) VALUES ('database_version', ?)", (self.CURRENT_VERSION,))
            conn.commit()
        logger.info(f"Datenbank initialisiert: {self.db_path} (Version {self.CURRENT_VERSION})")

    def _seed_if_empty(self):
        with sqlite3.connect(str(self.db_path)) as conn:
            cursor = conn.execute("SELECT COUNT(*) FROM dtc_codes")
            count = cursor.fetchone()[0]
        if count > 0 or not self.seed_path or not self.seed_path.exists():
            return
        with open(self.seed_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        seed_data = data.get("codes", data) if isinstance(data, dict) and "codes" in data else data
        for code, info in seed_data.items():
            self._insert(code, info)
        logger.info(f"Datenbank mit Seed-Daten befüllt: {len(seed_data)} Einträge")

    def _insert(self, code: str, info: Dict) -> None:
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO dtc_codes
                (code, title, description, severity, system, possible_causes, recommended_actions, extra)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (code, info.get("title", code), info.get("description", ""), info.get("severity", DTCSeverity.MEDIUM.value), info.get("system", DTCSystem.UNBEKANNT.value), json.dumps(info.get("possible_causes", [])), json.dumps(info.get("recommended_actions", [])), json.dumps(info.get("extra", {}))))
            conn.commit()

    def get(self, code: str) -> Optional[DtcCode]:
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("SELECT * FROM dtc_codes WHERE code = ?", (code,))
            row = cursor.fetchone()
        if not row:
            return None
        return self._row_to_dtc(row)

    def get_many(self, codes: List[str]) -> List[DtcCode]:
        if not codes:
            return []
        placeholders = ", ".join(["?"] * len(codes))
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(f"SELECT * FROM dtc_codes WHERE code IN ({placeholders})", codes)
            rows = cursor.fetchall()
        dtc_map = {row["code"]: self._row_to_dtc(row) for row in rows}
        return [dtc_map.get(code, DtcCode(code=code, title="Unbekannt", description="Unbekannter Fehlercode", severity=DTCSeverity.MEDIUM, system=DTCSystem.UNBEKANNT)) for code in codes]

    def update(self, new_data: Dict[str, Dict]) -> None:
        for code, info in new_data.items():
            self._insert(code, info)
        logger.info(f"Datenbank aktualisiert: {len(new_data)} Einträge")

    @staticmethod
    def _row_to_dtc(row) -> DtcCode:
        return DtcCode(
            code=row["code"],
            title=row["title"],
            description=row["description"],
            severity=DTCSeverity(row["severity"]) if row["severity"] in [s.value for s in DTCSeverity] else DTCSeverity.MEDIUM,
            system=DTCSystem(row["system"]) if row["system"] in [s.value for s in DTCSystem] else DTCSystem.UNBEKANNT,
            possible_causes=json.loads(row["possible_causes"]) if row["possible_causes"] else [],
            recommended_actions=json.loads(row["recommended_actions"]) if row["recommended_actions"] else [],
            extra=json.loads(row["extra"]) if row["extra"] else {}
        )