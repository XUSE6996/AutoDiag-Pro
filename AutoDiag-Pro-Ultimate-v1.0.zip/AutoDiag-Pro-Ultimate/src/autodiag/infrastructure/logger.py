import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler

def setup_logging(level: str = "INFO", log_file: Path | None = None,
                  max_bytes: int = 10_485_760, backup_count: int = 3) -> None:
    log_level = getattr(logging, level.upper(), logging.INFO)
    root = logging.getLogger()
    root.setLevel(log_level)

    console = logging.StreamHandler(sys.stdout)
    console.setLevel(log_level)
    console.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
    root.addHandler(console)

    if log_file:
        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(log_file, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8")
        file_handler.setLevel(log_level)
        file_handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"))
        root.addHandler(file_handler)

    for lib in ["obd", "matplotlib", "PIL"]:
        logging.getLogger(lib).setLevel(logging.WARNING)