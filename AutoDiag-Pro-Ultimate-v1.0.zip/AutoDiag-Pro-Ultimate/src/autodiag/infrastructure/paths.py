import sys
from pathlib import Path

def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).parents[3]

def get_data_dir() -> Path:
    return get_base_dir() / "data"

def get_logs_dir() -> Path:
    return get_base_dir() / "logs"

def get_reports_dir() -> Path:
    return get_base_dir() / "reports"

def get_resources_dir() -> Path:
    if getattr(sys, "frozen", False):
        return get_base_dir() / "resources"
    return Path(__file__).parent.parent / "resources"