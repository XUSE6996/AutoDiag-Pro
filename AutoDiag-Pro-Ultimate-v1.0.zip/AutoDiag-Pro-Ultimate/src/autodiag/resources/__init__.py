"""Resource package."""
