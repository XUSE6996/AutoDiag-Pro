from .config.settings import AppConfig
from .infrastructure.logger import setup_logging
from .infrastructure.paths import get_data_dir, get_reports_dir
from .core.adapter_factory import AdapterFactory
from .adapters.database.sqlite_adapter import SQLiteDTCAdapter
from .services.scan_service import ScanService
from .services.report_service import ReportService
from .services.live_data_service import LiveDataService
from .gui.controllers.main_controller import MainController
from .gui.main_window import MainWindow
import logging

logger = logging.getLogger(__name__)

class Application:
    def __init__(self, config: AppConfig):
        self.config = config
        setup_logging(level=config.log_level, log_file=config.log_file)

        self.obd_adapter = AdapterFactory.from_config(config)
        self.dtc_database = SQLiteDTCAdapter(db_path=config.db_path, seed_path=config.seed_db_path)
        self.scan_service = ScanService(obd_adapter=self.obd_adapter, dtc_database=self.dtc_database)
        self.report_service = ReportService(output_dir=config.report_dir)
        self.live_data_service = LiveDataService(adapter=self.obd_adapter, interval=0.5)

        self.controller = MainController(
            scan_service=self.scan_service,
            report_service=self.report_service,
            live_data_service=self.live_data_service,
            adapter_factory=AdapterFactory
        )
        self.main_window = MainWindow(self.controller)

    def run(self):
        logger.info("AutoDiag Pro Ultimate gestartet")
        self.main_window.run()
        logger.info("Anwendung beendet")