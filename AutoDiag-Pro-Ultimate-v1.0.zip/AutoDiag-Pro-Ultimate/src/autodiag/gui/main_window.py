import tkinter as tk
from tkinter import ttk
from .controllers.main_controller import MainController
from .tabs.diagnose_tab import DiagnoseTab
from .tabs.live_data_tab import LiveDataTab
from .tabs.reports_tab import ReportsTab
from .tabs.settings_tab import SettingsTab

class MainWindow:
    def __init__(self, controller: MainController):
        self.controller = controller
        self.root = tk.Tk()
        self.root.title("AutoDiag Pro – Ultimate Edition")
        self.root.geometry("1100x750")
        self.root.minsize(900, 600)

        self.main_frame = ttk.Frame(self.root, padding="5")
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self._create_header()
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=5)

        self.diagnose_tab = DiagnoseTab(self.notebook, controller)
        self.live_data_tab = LiveDataTab(self.notebook, controller)
        self.reports_tab = ReportsTab(self.notebook, controller)
        self.settings_tab = SettingsTab(self.notebook, controller)

        self.notebook.add(self.diagnose_tab, text="🚗 Diagnose")
        self.notebook.add(self.live_data_tab, text="📊 Live-Daten")
        self.notebook.add(self.reports_tab, text="📄 Berichte")
        self.notebook.add(self.settings_tab, text="⚙️ Einstellungen")

        self._create_statusbar()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _create_header(self):
        header_frame = ttk.Frame(self.main_frame)
        header_frame.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(header_frame, text="AutoDiag Pro", font=("Helvetica", 20, "bold")).pack(side=tk.LEFT)
        ttk.Label(header_frame, text="v1.0.0", font=("Helvetica", 10)).pack(side=tk.LEFT, padx=(10, 0))
        self.status_indicator = ttk.Label(header_frame, text="⏹ Getrennt", foreground="red")
        self.status_indicator.pack(side=tk.RIGHT)

    def _create_statusbar(self):
        self.status_var = tk.StringVar(value="Bereit")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W, padding=(5, 2))
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def set_status(self, text: str):
        self.status_var.set(text)

    def set_connection_status(self, connected: bool):
        if connected:
            self.status_indicator.config(text="🟢 Verbunden", foreground="green")
        else:
            self.status_indicator.config(text="⏹ Getrennt", foreground="red")

    def _on_close(self):
        self.live_data_tab.stop()
        self.root.destroy()

    def run(self):
        self.root.mainloop()