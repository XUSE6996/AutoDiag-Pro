import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from ...gui.controllers.main_controller import MainController

class SettingsTab(ttk.Frame):
    def __init__(self, parent, controller: MainController):
        super().__init__(parent)
        self.controller = controller
        self._build_ui()

    def _build_ui(self):
        main_frame = ttk.Frame(self, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(main_frame, text="⚙️ Einstellungen", font=("Helvetica", 16)).pack(pady=(0, 20))

        # Adapter
        adapter_frame = ttk.LabelFrame(main_frame, text="Adapter")
        adapter_frame.pack(fill=tk.X, pady=5)

        ttk.Label(adapter_frame, text="Standard-Adapter:").grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.adapter_var = tk.StringVar(value="simulator")
        adapter_combo = ttk.Combobox(adapter_frame, textvariable=self.adapter_var,
                                     values=["elm327", "canable", "simulator"], state="readonly", width=15)
        adapter_combo.grid(row=0, column=1, padx=10, pady=5, sticky="w")

        ttk.Label(adapter_frame, text="Timeout (Sekunden):").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.timeout_var = tk.StringVar(value="5.0")
        ttk.Entry(adapter_frame, textvariable=self.timeout_var, width=10).grid(row=1, column=1, padx=10, pady=5, sticky="w")

        # Datenbank
        db_frame = ttk.LabelFrame(main_frame, text="Datenbank")
        db_frame.pack(fill=tk.X, pady=5)

        ttk.Label(db_frame, text="Datenbank-Pfad:").grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.db_path_var = tk.StringVar(value=str(Path("data/autodiag.db").absolute()))
        ttk.Entry(db_frame, textvariable=self.db_path_var, width=50).grid(row=0, column=1, padx=10, pady=5, sticky="w")

        # Logging
        log_frame = ttk.LabelFrame(main_frame, text="Logging")
        log_frame.pack(fill=tk.X, pady=5)

        ttk.Label(log_frame, text="Log-Level:").grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.log_level_var = tk.StringVar(value="INFO")
        log_combo = ttk.Combobox(log_frame, textvariable=self.log_level_var,
                                 values=["DEBUG", "INFO", "WARNING", "ERROR"], state="readonly", width=10)
        log_combo.grid(row=0, column=1, padx=10, pady=5, sticky="w")

        ttk.Button(main_frame, text="💾 Einstellungen speichern", command=self._on_save).pack(pady=20)

    def _on_save(self):
        messagebox.showinfo("Info", "Einstellungen gespeichert (Funktion später verfügbar)")