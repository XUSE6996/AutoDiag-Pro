from .diagnose_tab import DiagnoseTab
from .live_data_tab import LiveDataTab
from .reports_tab import ReportsTab
from .settings_tab import SettingsTab