import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from ...gui.controllers.main_controller import MainController

class ReportsTab(ttk.Frame):
    def __init__(self, parent, controller: MainController):
        super().__init__(parent)
        self.controller = controller
        self._build_ui()

    def _build_ui(self):
        main_frame = ttk.Frame(self, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(main_frame, text="📄 Diagnosebericht erstellen", font=("Helvetica", 16)).pack(pady=(0, 20))

        info_frame = ttk.LabelFrame(main_frame, text="Informationen")
        info_frame.pack(fill=tk.X, pady=5)

        self.info_text = tk.Text(info_frame, height=8, wrap=tk.WORD, font=("Consolas", 10))
        self.info_text.pack(fill=tk.X, padx=10, pady=10)
        self.info_text.insert(tk.END, "Führen Sie einen Scan durch, um einen Bericht zu erstellen.")
        self.info_text.config(state=tk.DISABLED)

        self.report_btn = ttk.Button(main_frame, text="📄 PDF-Bericht erstellen", command=self._on_create_report)
        self.report_btn.pack(pady=20)

    def _on_create_report(self):
        result = self.controller.get_current_result()
        if result is None or result.error:
            messagebox.showwarning("Keine Daten", "Führen Sie zuerst einen Scan durch.")
            return

        filepath = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf"), ("Alle Dateien", "*.*")]
        )
        if not filepath:
            return

        try:
            output_path = self.controller.generate_report(Path(filepath).name)
            messagebox.showinfo("Erfolg", f"Bericht gespeichert:\n{output_path}")
        except Exception as e:
            messagebox.showerror("Fehler", f"Berichtserstellung fehlgeschlagen: {e}")