import tkinter as tk
from tkinter import ttk, messagebox
from ...gui.controllers.main_controller import MainController

class DiagnoseTab(ttk.Frame):
    def __init__(self, parent, controller: MainController):
        super().__init__(parent)
        self.controller = controller
        self._build_ui()

    def _build_ui(self):
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Einstellungen
        settings_frame = ttk.LabelFrame(main_frame, text="Diagnose-Einstellungen")
        settings_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(settings_frame, text="Adapter:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.adapter_var = tk.StringVar(value="simulator")
        adapter_combo = ttk.Combobox(settings_frame, textvariable=self.adapter_var,
                                     values=["elm327", "canable", "simulator"], state="readonly", width=15)
        adapter_combo.grid(row=0, column=1, padx=5, pady=5, sticky="w")

        ttk.Label(settings_frame, text="Port:").grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.port_var = tk.StringVar(value="")
        ttk.Entry(settings_frame, textvariable=self.port_var, width=15).grid(row=0, column=3, padx=5, pady=5)

        self.scan_btn = ttk.Button(settings_frame, text="🔍 Scan starten", command=self._on_scan)
        self.scan_btn.grid(row=0, column=4, padx=10, pady=5)

        self.clear_btn = ttk.Button(settings_frame, text="🗑 DTC löschen", command=self._on_clear_dtcs, state=tk.DISABLED)
        self.clear_btn.grid(row=0, column=5, padx=5, pady=5)

        # DTC-Liste
        result_frame = ttk.LabelFrame(main_frame, text="Fehlercodes")
        result_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        columns = ("code", "title", "severity", "system")
        self.dtc_tree = ttk.Treeview(result_frame, columns=columns, show="headings", height=8)
        self.dtc_tree.heading("code", text="Code")
        self.dtc_tree.heading("title", text="Beschreibung")
        self.dtc_tree.heading("severity", text="Schweregrad")
        self.dtc_tree.heading("system", text="System")
        self.dtc_tree.column("code", width=80)
        self.dtc_tree.column("title", width=300)
        self.dtc_tree.column("severity", width=100)
        self.dtc_tree.column("system", width=120)

        scrollbar = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=self.dtc_tree.yview)
        self.dtc_tree.configure(yscrollcommand=scrollbar.set)
        self.dtc_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Details
        detail_frame = ttk.LabelFrame(main_frame, text="Details")
        detail_frame.pack(fill=tk.BOTH, expand=True)
        self.detail_text = tk.Text(detail_frame, wrap=tk.WORD, height=6, font=("Consolas", 9))
        self.detail_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.dtc_tree.bind("<<TreeviewSelect>>", self._on_select_dtc)

    def _on_scan(self):
        self.scan_btn.config(state=tk.DISABLED)
        self.clear_btn.config(state=tk.DISABLED)
        self.dtc_tree.delete(*self.dtc_tree.get_children())
        self.detail_text.delete(1.0, tk.END)

        try:
            simulate = self.adapter_var.get() == "simulator"
            port = self.port_var.get() or None
            result = self.controller.run_scan(simulate=simulate, port=port)

            if result.error:
                messagebox.showerror("Fehler", result.error)
                return

            for dtc in result.dtc_codes:
                self.dtc_tree.insert("", tk.END, values=(
                    dtc.code,
                    dtc.title[:50] + ("..." if len(dtc.title) > 50 else ""),
                    dtc.severity.value,
                    dtc.system.value
                ))

            if result.dtc_codes:
                self.clear_btn.config(state=tk.NORMAL)
            self.controller.set_status(f"Scan abgeschlossen: {len(result.dtc_codes)} Fehlercodes")
        except Exception as e:
            messagebox.showerror("Fehler", f"Scan fehlgeschlagen: {e}")
        finally:
            self.scan_btn.config(state=tk.NORMAL)

    def _on_select_dtc(self, event):
        selection = self.dtc_tree.selection()
        if not selection:
            return
        code = self.dtc_tree.item(selection[0])["values"][0]
        result = self.controller.get_current_result()
        if not result:
            return

        for dtc in result.dtc_codes:
            if dtc.code == code:
                self.detail_text.delete(1.0, tk.END)
                self.detail_text.insert(tk.END, f"📌 {dtc.code}: {dtc.title}\n")
                self.detail_text.insert(tk.END, f"   Beschreibung: {dtc.description}\n")
                self.detail_text.insert(tk.END, f"   Schweregrad: {dtc.severity.value}\n")
                self.detail_text.insert(tk.END, f"   System: {dtc.system.value}\n\n")
                if dtc.possible_causes:
                    self.detail_text.insert(tk.END, "🔍 Mögliche Ursachen:\n")
                    for cause in dtc.possible_causes:
                        self.detail_text.insert(tk.END, f"   • {cause}\n")
                if dtc.recommended_actions:
                    self.detail_text.insert(tk.END, "\n🛠️ Empfohlene Prüfungen:\n")
                    for action in dtc.recommended_actions:
                        self.detail_text.insert(tk.END, f"   • {action}\n")
                break

    def _on_clear_dtcs(self):
        if not messagebox.askyesno("DTC löschen", "Möchten Sie alle Fehlercodes löschen?"):
            return
        try:
            if self.controller.clear_dtcs():
                self.dtc_tree.delete(*self.dtc_tree.get_children())
                self.detail_text.delete(1.0, tk.END)
                self.clear_btn.config(state=tk.DISABLED)
                self.controller.set_status("Fehlercodes gelöscht")
            else:
                messagebox.showerror("Fehler", "Löschen der Fehlercodes fehlgeschlagen")
        except Exception as e:
            messagebox.showerror("Fehler", f"Fehler: {e}")