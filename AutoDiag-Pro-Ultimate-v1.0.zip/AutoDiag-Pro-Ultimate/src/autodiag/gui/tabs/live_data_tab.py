import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from typing import List
from ...core.models import LiveData
from ...gui.controllers.main_controller import MainController

class LiveDataTab(ttk.Frame):
    def __init__(self, parent, controller: MainController):
        super().__init__(parent)
        self.controller = controller
        self._running = False
        self._data_points: List[LiveData] = []
        self._max_points = 100
        self._build_ui()

    def _build_ui(self):
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Steuerung
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        self.start_btn = ttk.Button(control_frame, text="▶ Live-Daten starten", command=self._on_start)
        self.start_btn.pack(side=tk.LEFT, padx=5)
        self.stop_btn = ttk.Button(control_frame, text="⏹ Stoppen", command=self._on_stop, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)

        # Diagramm
        chart_frame = ttk.Frame(main_frame)
        chart_frame.pack(fill=tk.BOTH, expand=True)
        self.figure = Figure(figsize=(8, 5), dpi=100)
        self.ax = self.figure.add_subplot(111)
        self.ax.set_title("Live-Daten – Drehzahl (RPM)")
        self.ax.set_xlabel("Zeit")
        self.ax.set_ylabel("RPM")
        self.ax.grid(True)
        self.canvas = FigureCanvasTkAgg(self.figure, master=chart_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # Werte-Anzeige
        values_frame = ttk.LabelFrame(main_frame, text="Aktuelle Werte")
        values_frame.pack(fill=tk.X, pady=(10, 0))
        self.value_labels = {}
        rows = [
            ("Drehzahl", "rpm", "{:.0f} 1/min"),
            ("Geschwindigkeit", "speed", "{:.1f} km/h"),
            ("Kühlmitteltemp.", "coolant_temp", "{:.0f} °C"),
            ("Motorlast", "engine_load", "{:.1f} %"),
            ("Drosselklappe", "throttle_position", "{:.1f} %"),
            ("MAF", "maf", "{:.2f} g/s"),
            ("MAP", "map", "{:.1f} kPa"),
            ("Lambda", "lambda_value", "{:.2f} λ"),
            ("Batterie", "battery_voltage", "{:.1f} V"),
            ("Tankfüllung", "fuel_level", "{:.0f} %"),
        ]
        for i, (label, attr, fmt) in enumerate(rows):
            row = i // 4
            col = i % 4
            ttk.Label(values_frame, text=f"{label}:").grid(row=row, column=col*2, padx=5, pady=2, sticky="e")
            self.value_labels[attr] = ttk.Label(values_frame, text="--", font=("Consolas", 10, "bold"))
            self.value_labels[attr].grid(row=row, column=col*2+1, padx=5, pady=2, sticky="w")

    def _on_start(self):
        self._running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self._data_points.clear()
        self.controller.start_live_data(callback=self._on_data_received)

    def _on_stop(self):
        self._running = False
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.controller.stop_live_data()

    def _on_data_received(self, data: LiveData):
        if not self._running:
            return
        self._data_points.append(data)
        if len(self._data_points) > self._max_points:
            self._data_points.pop(0)
        self._update_values(data)
        if len(self._data_points) % 5 == 0:
            self._update_chart()

    def _update_values(self, data: LiveData):
        for attr, label in self.value_labels.items():
            value = getattr(data, attr)
            if value is not None:
                fmt = {
                    "rpm": "{:.0f} 1/min",
                    "speed": "{:.1f} km/h",
                    "coolant_temp": "{:.0f} °C",
                    "engine_load": "{:.1f} %",
                    "throttle_position": "{:.1f} %",
                    "maf": "{:.2f} g/s",
                    "map": "{:.1f} kPa",
                    "lambda_value": "{:.2f} λ",
                    "battery_voltage": "{:.1f} V",
                    "fuel_level": "{:.0f} %",
                }.get(attr, "{}")
                label.config(text=fmt.format(value))

    def _update_chart(self):
        if not self._data_points:
            return
        rpms = [d.rpm for d in self._data_points if d.rpm is not None]
        if not rpms:
            return
        self.ax.clear()
        self.ax.plot(rpms, 'b-', linewidth=2)
        self.ax.set_title("Live-Daten – Drehzahl (RPM)")
        self.ax.set_xlabel("Zeit (Sekunden)")
        self.ax.set_ylabel("RPM")
        self.ax.grid(True)
        self.ax.set_ylim(0, max(rpms) * 1.2 if rpms else 1000)
        self.canvas.draw()

    def stop(self):
        self._on_stop()