from typing import Optional, Callable
from pathlib import Path
from ...services.scan_service import ScanService
from ...services.report_service import ReportService
from ...services.live_data_service import LiveDataService
from ...core.models import ScanResult, LiveData
from ...core.adapter_factory import AdapterFactory
import logging

logger = logging.getLogger(__name__)

class MainController:
    def __init__(
        self,
        scan_service: ScanService,
        report_service: ReportService,
        live_data_service: LiveDataService,
        adapter_factory: type[AdapterFactory]
    ):
        self.scan_service = scan_service
        self.report_service = report_service
        self.live_data_service = live_data_service
        self.adapter_factory = adapter_factory
        self._current_result: Optional[ScanResult] = None
        self._live_data_callback: Optional[Callable[[LiveData], None]] = None

    # ─── Scan ──────────────────────────────────────────────────────
    def run_scan(self, simulate: bool, port: str = "") -> ScanResult:
        new_adapter = self.adapter_factory.create(
            adapter_type="simulator" if simulate else "elm327",
            port=port or None
        )
        self.scan_service.obd_adapter = new_adapter
        self._current_result = self.scan_service.perform_scan()
        return self._current_result

    def get_current_result(self) -> Optional[ScanResult]:
        return self._current_result

    def clear_dtcs(self) -> bool:
        return self.scan_service.clear_dtcs()

    # ─── Berichte ──────────────────────────────────────────────────
    def generate_report(self, filename: Optional[str] = None) -> Path:
        if self._current_result is None:
            raise ValueError("Kein Scan-Ergebnis vorhanden")
        return self.report_service.generate_pdf(self._current_result, filename)

    # ─── Live-Daten ────────────────────────────────────────────────
    def start_live_data(self, callback: Callable[[LiveData], None]) -> None:
        self._live_data_callback = callback
        self.live_data_service.add_callback(callback)
        self.live_data_service.start()

    def stop_live_data(self) -> None:
        if self._live_data_callback:
            self.live_data_service.remove_callback(self._live_data_callback)
            self._live_data_callback = None
        self.live_data_service.stop()

    def get_latest_live_data(self) -> Optional[LiveData]:
        return self.live_data_service.get_latest_data()

    # ─── Status ────────────────────────────────────────────────────
    def set_status(self, text: str):
        # Wird von MainWindow verwendet
        pass