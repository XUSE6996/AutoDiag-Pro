#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from autodiag.config.settings import AppConfig
from autodiag.app import Application

def main():
    config = AppConfig.load()
    if not config.obd_port and not config.obd_simulation:
        config.obd_simulation = True
    app = Application(config)
    app.run()

if __name__ == "__main__":
    main()