import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
from ..infrastructure.paths import get_data_dir, get_logs_dir, get_reports_dir, get_resources_dir

@dataclass
class AppConfig:
    obd_adapter_type: str = "simulator"
    obd_port: Optional[str] = None
    obd_timeout: float = 5.0
    obd_simulation: bool = True

    db_path: Path = field(default_factory=lambda: get_data_dir() / "autodiag.db")
    seed_db_path: Optional[Path] = field(
        default_factory=lambda: get_resources_dir() / "dtc_codes_seed.json"
    )

    log_level: str = "INFO"
    log_file: Optional[Path] = field(default_factory=lambda: get_logs_dir() / "autodiag.log")
    log_max_bytes: int = 10 * 1024 * 1024
    log_backup_count: int = 3

    report_dir: Path = field(default_factory=get_reports_dir)
    window_size: tuple = (1100, 750)

    @classmethod
    def load(cls) -> "AppConfig":
        config = cls()
        for key in cls.__dataclass_fields__.keys():
            env_key = f"AUTODIAG_{key.upper()}"
            if env_key in os.environ:
                val = os.environ[env_key]
                if key in ("obd_timeout", "log_max_bytes"):
                    val = float(val)
                elif key in ("obd_simulation",):
                    val = val.lower() in ("true", "1", "yes")
                elif key in ("db_path", "seed_db_path", "log_file", "report_dir"):
                    val = Path(val)
                setattr(config, key, val)
        return config