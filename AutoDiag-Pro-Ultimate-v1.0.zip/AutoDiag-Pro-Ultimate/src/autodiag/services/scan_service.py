from typing import Optional
import logging
from ..core.interfaces import IOBDAdapter, IDTCDatabase
from ..core.models import ScanResult
from ..core.dtc_decoder import DtcDecoder
from ..core.exceptions import OBDConnectionError

logger = logging.getLogger(__name__)

class ScanService:
    def __init__(self, obd_adapter: IOBDAdapter, dtc_database: IDTCDatabase):
        self.obd_adapter = obd_adapter
        self.decoder = DtcDecoder(dtc_database)

    def perform_scan(self, keep_connected: bool = False) -> ScanResult:
        result = ScanResult()
        if not self.obd_adapter.connect():
            result.error = "Keine Verbindung zum OBD-II-Adapter."
            return result
        try:
            result.vehicle_info = self.obd_adapter.get_vehicle_info()
            raw_dtcs = self.obd_adapter.get_dtcs()
            if raw_dtcs is None:
                result.error = "Fehler beim Auslesen der Fehlercodes."
                return result
            result.raw_dtc_list = raw_dtcs
            result.dtc_codes = self.decoder.decode_many(raw_dtcs) if raw_dtcs else []
            result.adapter_info = {"simulated": self.obd_adapter.is_connected()}
        except OBDConnectionError as e:
            result.error = f"Verbindungsfehler: {e}"
        except Exception as e:
            result.error = f"Unerwarteter Fehler: {e}"
            logger.exception(result.error)
        finally:
            if not keep_connected:
                self.obd_adapter.disconnect()
        return result

    def clear_dtcs(self) -> bool:
        if not self.obd_adapter.is_connected():
            if not self.obd_adapter.connect():
                return False
        try:
            return self.obd_adapter.clear_dtcs()
        finally:
            self.obd_adapter.disconnect()