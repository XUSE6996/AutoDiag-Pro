from pathlib import Path
from datetime import datetime
from typing import Optional
import logging
from ..core.models import ScanResult

logger = logging.getLogger(__name__)

class ReportService:
    def __init__(self, output_dir: Path):
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_pdf(self, result: ScanResult, filename: Optional[str] = None) -> Path:
        if filename is None:
            filename = f"diagnosebericht_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        output_path = self.output_dir / filename
        self._create_pdf(result, output_path)
        logger.info(f"PDF-Bericht erstellt: {output_path}")
        return output_path

    def _create_pdf(self, result: ScanResult, output_path: Path):
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import cm

        doc = SimpleDocTemplate(str(output_path), pagesize=A4)
        styles = getSampleStyleSheet()
        story = []

        story.append(Paragraph("AutoDiag Pro – Diagnosebericht", styles['Title']))
        story.append(Spacer(1, 0.5 * cm))
        story.append(Paragraph(f"Erstellt: {result.timestamp.strftime('%d.%m.%Y %H:%M')}", styles['Normal']))
        story.append(Spacer(1, 0.5 * cm))

        if result.vehicle_info:
            story.append(Paragraph("Fahrzeuginformationen:", styles['Heading2']))
            for key, val in result.vehicle_info.items():
                story.append(Paragraph(f"{key}: {val}", styles['Normal']))
            story.append(Spacer(1, 0.5 * cm))

        if result.dtc_codes:
            story.append(Paragraph(f"Gefundene Fehlercodes ({len(result.dtc_codes)}):", styles['Heading2']))
            for dtc in result.dtc_codes:
                story.append(Paragraph(f"<b>{dtc.code}</b>: {dtc.title}", styles['Normal']))
                story.append(Paragraph(f"Schweregrad: {dtc.severity.value}", styles['Normal']))
                story.append(Paragraph(f"System: {dtc.system.value}", styles['Normal']))
                if dtc.possible_causes:
                    story.append(Paragraph("Mögliche Ursachen:", styles['Normal']))
                    for cause in dtc.possible_causes:
                        story.append(Paragraph(f"• {cause}", styles['Normal']))
                if dtc.recommended_actions:
                    story.append(Paragraph("Empfohlene Prüfungen:", styles['Normal']))
                    for action in dtc.recommended_actions:
                        story.append(Paragraph(f"• {action}", styles['Normal']))
                story.append(Spacer(1, 0.3 * cm))
        else:
            story.append(Paragraph("✅ Keine Fehlercodes gefunden.", styles['Normal']))

        story.append(Spacer(1, 1 * cm))
        story.append(Paragraph("AutoDiag Pro – Ihr Partner für Fahrzeugdiagnose", styles['Italic']))
        doc.build(story)