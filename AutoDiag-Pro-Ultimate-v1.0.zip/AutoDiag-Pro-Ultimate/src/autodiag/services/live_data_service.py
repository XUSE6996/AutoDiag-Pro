import threading
import time
from typing import Optional, Callable, List
import logging
from ..core.interfaces import IOBDAdapter
from ..core.models import LiveData
from ..core.exceptions import OBDConnectionError

logger = logging.getLogger(__name__)

class LiveDataService:
    def __init__(self, adapter: IOBDAdapter, interval: float = 0.5):
        self.adapter = adapter
        self.interval = interval
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._callbacks: List[Callable[[LiveData], None]] = []
        self._last_data: Optional[LiveData] = None
        self._lock = threading.Lock()

    def start(self) -> bool:
        if self._running:
            return True
        if not self.adapter.is_connected():
            if not self.adapter.connect():
                raise OBDConnectionError("Adapter nicht verbunden")
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        logger.info("Live-Daten-Stream gestartet")
        return True

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)
        logger.info("Live-Daten-Stream gestoppt")

    def _run(self) -> None:
        while self._running:
            try:
                data = self.adapter.get_live_data()
                if data:
                    with self._lock:
                        self._last_data = data
                    for callback in self._callbacks:
                        try:
                            callback(data)
                        except Exception as e:
                            logger.exception(f"Callback-Fehler: {e}")
            except Exception as e:
                logger.exception(f"Live-Daten-Fehler: {e}")
            time.sleep(self.interval)

    def get_latest_data(self) -> Optional[LiveData]:
        with self._lock:
            return self._last_data

    def add_callback(self, callback: Callable[[LiveData], None]) -> None:
        self._callbacks.append(callback)

    def remove_callback(self, callback: Callable[[LiveData], None]) -> None:
        if callback in self._callbacks:
            self._callbacks.remove(callback)