"""Factory für OBD-Adapter – ermöglicht dynamischen Wechsel."""
from typing import Optional
from .interfaces import IOBDAdapter
from ..adapters.obd.elm327_adapter import ELM327Adapter
from ..adapters.obd.canable_adapter import CANableAdapter
from ..adapters.obd.advanced_simulator import AdvancedSimulator
from ..config.settings import AppConfig
import logging

logger = logging.getLogger(__name__)

class AdapterFactory:
    """Erzeugt OBD-Adapter basierend auf Konfiguration oder Parametern."""

    @staticmethod
    def create(
        adapter_type: str = "simulator",
        port: Optional[str] = None,
        timeout: float = 5.0,
        scenario: str = "keine_fehlers"
    ) -> IOBDAdapter:
        if adapter_type == "elm327":
            logger.info(f"ELM327-Adapter (Port: {port or 'Auto'})")
            return ELM327Adapter(port=port, timeout=timeout)

        elif adapter_type == "canable":
            logger.info(f"CANable-Adapter (Port: {port or 'Auto'})")
            return CANableAdapter(port=port or "auto", timeout=timeout)

        elif adapter_type == "simulator":
            logger.info(f"Simulator gestartet (Szenario: {scenario})")
            return AdvancedSimulator(scenario=scenario)

        else:
            raise ValueError(f"Unbekannter Adapter-Typ: {adapter_type}")

    @staticmethod
    def from_config(config: AppConfig) -> IOBDAdapter:
        """Erstellt einen Adapter aus der Konfiguration."""
        adapter_type = "simulator" if config.obd_simulation else config.obd_adapter_type
        return AdapterFactory.create(
            adapter_type=adapter_type,
            port=config.obd_port,
            timeout=config.obd_timeout
        )