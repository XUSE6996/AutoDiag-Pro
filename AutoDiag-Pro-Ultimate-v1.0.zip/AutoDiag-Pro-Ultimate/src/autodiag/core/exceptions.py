"""Benutzerdefinierte Ausnahmen – ohne Überschreibung von Python-Builtins."""

class AutoDiagError(Exception):
    """Basis-Exception für alle projektspezifischen Fehler."""
    pass

class OBDConnectionError(AutoDiagError):
    """Fehler bei der Verbindung zum OBD-II-Adapter."""
    pass

class OBDCommunicationError(AutoDiagError):
    """Fehler bei der Kommunikation mit dem OBD-II-Adapter."""
    pass

class DatabaseError(AutoDiagError):
    """Fehler bei Datenbankoperationen."""
    pass

class DecodeError(AutoDiagError):
    """Fehler beim Decodieren von DTCs."""
    pass

class ValidationError(AutoDiagError):
    """Fehler bei der Eingabevalidierung."""
    pass

class LicenseError(AutoDiagError):
    """Fehler bei der Lizenzprüfung."""
    pass

class LiveDataError(AutoDiagError):
    """Fehler beim Live-Daten-Streaming."""
    pass