"""Abstrakte Interfaces für alle Core-Komponenten."""
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from .models import DtcCode, LiveData, FreezeFrame, VehicleProfile

class IOBDAdapter(ABC):
    """Interface für OBD-II-Adapter (echt oder simuliert)."""

    @abstractmethod
    def connect(self) -> bool:
        """Stellt Verbindung her. Gibt True bei Erfolg zurück."""
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Trennt die Verbindung."""
        pass

    @abstractmethod
    def get_dtcs(self) -> Optional[List[str]]:
        """Liest Fehlercodes aus. Gibt Liste der DTC-Strings oder None bei Fehler."""
        pass

    @abstractmethod
    def clear_dtcs(self) -> bool:
        """Löscht alle Fehlercodes. Gibt True bei Erfolg zurück."""
        pass

    @abstractmethod
    def get_live_data(self) -> Optional[LiveData]:
        """Liest Live-Daten aus."""
        pass

    @abstractmethod
    def get_freeze_frame(self, dtc: str) -> Optional[FreezeFrame]:
        """Liest Freeze Frame für einen DTC aus."""
        pass

    @abstractmethod
    def get_vehicle_info(self) -> Dict[str, str]:
        """Liest Fahrzeuginformationen (VIN etc.)."""
        pass

    @abstractmethod
    def is_connected(self) -> bool:
        """Prüft, ob eine Verbindung besteht."""
        pass

class IDTCDatabase(ABC):
    """Interface für DTC-Datenbank."""

    @abstractmethod
    def get(self, code: str) -> Optional[DtcCode]:
        """Ruft einen einzelnen DTC ab. Gibt None zurück, falls nicht vorhanden."""
        pass

    @abstractmethod
    def get_many(self, codes: List[str]) -> List[DtcCode]:
        """Ruft mehrere DTCs ab. Fehlende Codes werden als 'unbekannt' zurückgegeben."""
        pass

    @abstractmethod
    def update(self, new_data: Dict[str, Dict]) -> None:
        """Aktualisiert oder fügt DTCs hinzu."""
        pass

class IVehicleRepository(ABC):
    """Interface für Fahrzeugprofile."""

    @abstractmethod
    def save(self, profile: VehicleProfile) -> int:
        """Speichert ein Fahrzeugprofil. Gibt ID zurück."""
        pass

    @abstractmethod
    def get(self, profile_id: int) -> Optional[VehicleProfile]:
        """Ruft ein Profil ab."""
        pass

    @abstractmethod
    def list_all(self) -> List[VehicleProfile]:
        """Listet alle Profile auf."""
        pass

    @abstractmethod
    def delete(self, profile_id: int) -> bool:
        """Löscht ein Profil."""
        pass