"""Datenmodelle – Ultimate Edition mit Live-Daten, Freeze Frame und Fahrzeugprofilen."""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

class DTCSeverity(Enum):
    """Schweregrad eines Fehlercodes."""
    LOW = "Niedrig"
    MEDIUM = "Mittel"
    HIGH = "Hoch"
    CRITICAL = "Kritisch"

class DTCSystem(Enum):
    """Fahrzeugsystem-Kategorien."""
    ENGINE = "Motor"
    ABGAS = "Abgassystem"
    KRAFTSTOFF = "Kraftstoffsystem"
    ZUENDUNG = "Zündung"
    GETRIEBE = "Getriebe"
    BREMSEN = "Bremssystem"
    ELEKTRIK = "Elektrik"
    KOMMUNIKATION = "Kommunikation"
    UNBEKANNT = "Unbekannt"

@dataclass
class DtcCode:
    """Erweiterter Fehlercode mit System-Klassifizierung."""
    code: str
    title: str = ""
    description: str = ""
    severity: DTCSeverity = DTCSeverity.MEDIUM
    system: DTCSystem = DTCSystem.UNBEKANNT
    possible_causes: List[str] = field(default_factory=list)
    recommended_actions: List[str] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)

    @property
    def full_description(self) -> str:
        return f"{self.code}: {self.title}\n{self.description}"

@dataclass
class LiveData:
    """Live-Daten vom Fahrzeug."""
    timestamp: datetime = field(default_factory=datetime.now)
    rpm: Optional[float] = None
    speed: Optional[float] = None
    coolant_temp: Optional[float] = None
    engine_load: Optional[float] = None
    throttle_position: Optional[float] = None
    maf: Optional[float] = None
    map: Optional[float] = None
    lambda_value: Optional[float] = None
    battery_voltage: Optional[float] = None
    fuel_level: Optional[float] = None
    intake_temp: Optional[float] = None
    timing_advance: Optional[float] = None
    custom: Dict[str, float] = field(default_factory=dict)

@dataclass
class FreezeFrame:
    """Eingefrorene Daten bei Fehlerauftreten."""
    timestamp: datetime
    dtc_code: str
    live_data: LiveData
    environment: Dict[str, str] = field(default_factory=dict)

@dataclass
class VehicleProfile:
    """Fahrzeugprofil mit Historie."""
    id: Optional[int] = None
    name: str = ""
    make: str = ""
    model: str = ""
    year: int = 0
    vin: str = ""
    engine: str = ""
    mileage: int = 0
    license_plate: str = ""
    notes: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    scan_history: List['ScanResult'] = field(default_factory=list)

@dataclass
class ScanResult:
    """Erweitertes Scan-Ergebnis mit Historie."""
    id: Optional[int] = None
    timestamp: datetime = field(default_factory=datetime.now)
    vehicle_profile: Optional[VehicleProfile] = None
    dtc_codes: List[DtcCode] = field(default_factory=list)
    raw_dtc_list: List[str] = field(default_factory=list)
    live_data_snapshot: Optional[LiveData] = None
    freeze_frame: Optional[FreezeFrame] = None
    vehicle_info: Dict[str, str] = field(default_factory=dict)
    adapter_info: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    notes: str = ""