from .models import DtcCode, DTCSeverity, DTCSystem
from .interfaces import IDTCDatabase
from typing import List

class DtcDecoder:
    def __init__(self, database: IDTCDatabase):
        self.database = database

    def decode(self, code: str) -> DtcCode:
        dtc = self.database.get(code)
        if dtc is None:
            return DtcCode(code=code, title="Unbekannt", description="Unbekannter Fehlercode",
                           severity=DTCSeverity.MEDIUM, system=DTCSystem.UNBEKANNT)
        return dtc

    def decode_many(self, codes: List[str]) -> List[DtcCode]:
        return self.database.get_many(codes)