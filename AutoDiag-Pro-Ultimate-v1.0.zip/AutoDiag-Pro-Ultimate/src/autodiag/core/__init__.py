"""Core-Modul – Domänenlogik und Interfaces."""
from .models import DtcCode, LiveData, ScanResult, VehicleProfile, FreezeFrame, DTCSeverity, DTCSystem
from .interfaces import IOBDAdapter, IDTCDatabase
from .exceptions import AutoDiagError, OBDConnectionError, DatabaseError, DecodeError, LicenseError
from .adapter_factory import AdapterFactory

__all__ = [
    "DtcCode", "LiveData", "ScanResult", "VehicleProfile", "FreezeFrame",
    "DTCSeverity", "DTCSystem",
    "IOBDAdapter", "IDTCDatabase",
    "AutoDiagError", "OBDConnectionError", "DatabaseError", "DecodeError", "LicenseError",
    "AdapterFactory"
]