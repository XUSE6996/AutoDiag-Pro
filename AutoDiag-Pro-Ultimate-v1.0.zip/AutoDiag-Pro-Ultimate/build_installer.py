#!/usr/bin/env python3
import subprocess
import sys
from pathlib import Path

def main():
    subprocess.run([sys.executable, "scripts/build_exe.py"], check=True)
    nsis_script = Path("scripts/build_installer.nsi")
    if not nsis_script.exists():
        print("❌ build_installer.nsi nicht gefunden")
        sys.exit(1)
    subprocess.run(["makensis", str(nsis_script)], check=True)
    print("✅ Installer erstellt: dist/AutoDiagPro_Setup.exe")

if __name__ == "__main__":
    main()