"""Unit-Tests für Datenmodelle."""
from autodiag.core.models import DtcCode, DTCSeverity, DTCSystem

def test_dtc_code_creation():
    dtc = DtcCode(
        code="P0420",
        title="Katalysator",
        severity=DTCSeverity.MEDIUM,
        system=DTCSystem.ABGAS
    )
    assert dtc.code == "P0420"
    assert dtc.severity == DTCSeverity.MEDIUM