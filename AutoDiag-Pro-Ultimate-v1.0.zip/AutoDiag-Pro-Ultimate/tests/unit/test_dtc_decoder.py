"""Tests für DTC-Decoder."""
from autodiag.core.dtc_decoder import DtcDecoder
from autodiag.adapters.database.sqlite_adapter import SQLiteDTCAdapter
import tempfile
from pathlib import Path

def test_decode_known_code():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = Path(f.name)
    db = SQLiteDTCAdapter(db_path)
    # Seed einfügen
    db._insert("P0420", {"title": "Kat", "description": "Test", "severity": "Mittel", "system": "Abgassystem"})
    decoder = DtcDecoder(db)
    dtc = decoder.decode("P0420")
    assert dtc.title == "Kat"
    db_path.unlink()