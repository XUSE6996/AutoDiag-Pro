from autodiag.services.scan_service import ScanService

def test_scan_flow(simulator, temp_db):
    service = ScanService(obd_adapter=simulator, dtc_database=temp_db)
    result = service.perform_scan()
    assert result.error is None
    assert result.raw_dtc_list is not None