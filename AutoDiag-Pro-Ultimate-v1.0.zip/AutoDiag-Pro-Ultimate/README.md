# AutoDiag Pro – Ultimate Edition

**Offline-fähiges professionelles Diagnose-Tool für Kfz-Werkstätten, mobile Dienste und Hobby-Schrauber.**

## Features

- ✅ OBD-II Diagnose (ELM327, CANable, Simulator)
- ✅ Live-Daten (RPM, Temperatur, Lambda, MAF, MAP, Batterie)
- ✅ Fehlercodes auslesen, decodieren, löschen
- ✅ Freeze Frame
- ✅ Fahrzeugprofile und Scan-Historie
- ✅ Professionelle PDF-Berichte
- ✅ Simulationsmodus für Demo und Schulungen
- ✅ 200+ DTCs in SQLite-Datenbank

## Erweiterte Dokumentation

Siehe docs/reports für Review, Roadmap und Marktanalyse.

## Installation
