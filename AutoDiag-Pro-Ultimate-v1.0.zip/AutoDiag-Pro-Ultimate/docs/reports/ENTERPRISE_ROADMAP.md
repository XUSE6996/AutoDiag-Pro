# Enterprise Ausbauplan

## Version 2.x
- Werkstatt-Mandantenverwaltung
- Cloud-Synchronisation optional
- Benutzerrollen
- erweitertes Fahrzeugarchiv

## Version 3.x
- KI-gestützte Fehleranalyse
- Herstellerwissen als Plugin
- Flottenverwaltung
