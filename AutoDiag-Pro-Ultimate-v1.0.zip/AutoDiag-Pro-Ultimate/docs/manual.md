# AutoDiag Pro – Bedienungsanleitung

## Schnellstart
1. OBD-Adapter anschließen.
2. Programm starten.
3. Im Tab "Diagnose" Adapter wählen und "Scan starten".
4. Fehlercodes werden angezeigt.
5. Im Tab "Live-Daten" Echtzeitwerte verfolgen.
6. Berichte als PDF exportieren.

## Adapter
- ELM327 (USB/Bluetooth) – für OBD-II.
- CANable (USB-CAN) – für CAN-Analyse.
- Simulator – für Demo und Schulungen.